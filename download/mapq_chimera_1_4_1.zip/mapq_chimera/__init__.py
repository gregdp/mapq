mapqVersion = '1.0'
