mapqVersion = '1.6.1'
