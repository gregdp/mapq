import mapq
import mapq.qscores
mapq.qscores.Calc('/Users/greg/Desktop/Chimera.app/Contents/MacOS/chimera',6,1.500000,-1.000000,0.600000)
