import mapq
import mapq.mapq
mapq.mapq.Calc('/Users/greg/Desktop/Chimera.app/Contents/MacOS/chimera',1,1.750000)
