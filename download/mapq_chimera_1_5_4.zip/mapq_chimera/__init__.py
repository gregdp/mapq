mapqVersion = '1.5.4'
