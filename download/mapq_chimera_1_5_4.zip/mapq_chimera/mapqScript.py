import mapq
import mapq.mapq
mapq.mapq.Calc('/Users/greg/Desktop/Chimera.app/Contents/MacOS/chimera',4,1.750000,200.000000)
