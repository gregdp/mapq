showDevTools = False    # some new also under-development tools
mapqVersion = '1.6.7'
